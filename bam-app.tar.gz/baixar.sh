
git remote -v
git fetch https://lucasnpinheiro@github.com/lucasnpinheiro/bam-app.git +refs/heads/master:refs/remotes/origin/master
git merge --ff origin/master
