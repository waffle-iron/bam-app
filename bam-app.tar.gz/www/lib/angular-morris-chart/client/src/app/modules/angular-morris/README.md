# angular-morris
> [Appfy based](https://appfy.org) module that wraps `morris.js` charts.