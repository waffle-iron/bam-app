## angular-morris
[![Build Status](https://travis-ci.org/st1s/angular-morris.svg)](https://travis-ci.org/st1s/angular-morris) [![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

Easy use of morris.js with angular.js

## Install
Install `angular-morris` through bower or npm. Checkout [the docs](https://angular-morris.io/docs).


## License
MIT