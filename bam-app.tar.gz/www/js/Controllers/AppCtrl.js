angular.module('starter')

        .controller('AppCtrl', function ($rootScope, $scope) {

        });
